export class Account {
    constructor(id, name, email, isEmployee, departmentId) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.isEmployee = isEmployee;
        this.departmentId = departmentId;
    }
}
